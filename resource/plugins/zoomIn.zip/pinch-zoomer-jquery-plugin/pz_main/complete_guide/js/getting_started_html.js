(function()
{
	$(prettyPrint);
})();