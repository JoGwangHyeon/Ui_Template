$(onReady);

function onReady()
{
	prettyPrint();	
}